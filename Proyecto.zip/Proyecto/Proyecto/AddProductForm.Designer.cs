﻿namespace Proyecto
{
    partial class AddProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnMovil = new System.Windows.Forms.RadioButton();
            this.rbtnOrdenador = new System.Windows.Forms.RadioButton();
            this.groupDatosOrdenador = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnImagenPC = new System.Windows.Forms.Button();
            this.txtPrecioPC = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtProcesadorPC = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAlmacenamientoPC = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtRAMPC = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtGPUPC = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMarcaPC = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCodigoPC = new System.Windows.Forms.TextBox();
            this.groupDatosMovil = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtPrecioMovil = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtProcesadorMovil = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnImagenMovil = new System.Windows.Forms.Button();
            this.txtCamaraMovil = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAlmacenamientoMovil = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtRAMMovil = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtModeloMovil = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtMarcaMovil = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCodigoMovil = new System.Windows.Forms.TextBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.lblNingunaImagenCargada = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupDatosOrdenador.SuspendLayout();
            this.groupDatosMovil.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnMovil);
            this.groupBox1.Controls.Add(this.rbtnOrdenador);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seleccionar tipo";
            // 
            // rbtnMovil
            // 
            this.rbtnMovil.AutoSize = true;
            this.rbtnMovil.Location = new System.Drawing.Point(7, 44);
            this.rbtnMovil.Name = "rbtnMovil";
            this.rbtnMovil.Size = new System.Drawing.Size(50, 17);
            this.rbtnMovil.TabIndex = 1;
            this.rbtnMovil.TabStop = true;
            this.rbtnMovil.Text = "Móvil";
            this.rbtnMovil.UseVisualStyleBackColor = true;
            this.rbtnMovil.CheckedChanged += new System.EventHandler(this.rbtnMovil_CheckedChanged);
            // 
            // rbtnOrdenador
            // 
            this.rbtnOrdenador.AutoSize = true;
            this.rbtnOrdenador.Location = new System.Drawing.Point(7, 20);
            this.rbtnOrdenador.Name = "rbtnOrdenador";
            this.rbtnOrdenador.Size = new System.Drawing.Size(75, 17);
            this.rbtnOrdenador.TabIndex = 0;
            this.rbtnOrdenador.TabStop = true;
            this.rbtnOrdenador.Text = "Ordenador";
            this.rbtnOrdenador.UseVisualStyleBackColor = true;
            this.rbtnOrdenador.CheckedChanged += new System.EventHandler(this.rbtnOrdenador_CheckedChanged);
            // 
            // groupDatosOrdenador
            // 
            this.groupDatosOrdenador.Controls.Add(this.label19);
            this.groupDatosOrdenador.Controls.Add(this.label17);
            this.groupDatosOrdenador.Controls.Add(this.label8);
            this.groupDatosOrdenador.Controls.Add(this.btnImagenPC);
            this.groupDatosOrdenador.Controls.Add(this.txtPrecioPC);
            this.groupDatosOrdenador.Controls.Add(this.label7);
            this.groupDatosOrdenador.Controls.Add(this.txtProcesadorPC);
            this.groupDatosOrdenador.Controls.Add(this.label6);
            this.groupDatosOrdenador.Controls.Add(this.txtAlmacenamientoPC);
            this.groupDatosOrdenador.Controls.Add(this.label5);
            this.groupDatosOrdenador.Controls.Add(this.txtRAMPC);
            this.groupDatosOrdenador.Controls.Add(this.label4);
            this.groupDatosOrdenador.Controls.Add(this.txtGPUPC);
            this.groupDatosOrdenador.Controls.Add(this.label3);
            this.groupDatosOrdenador.Controls.Add(this.txtMarcaPC);
            this.groupDatosOrdenador.Controls.Add(this.label1);
            this.groupDatosOrdenador.Controls.Add(this.txtCodigoPC);
            this.groupDatosOrdenador.Location = new System.Drawing.Point(218, 12);
            this.groupDatosOrdenador.Name = "groupDatosOrdenador";
            this.groupDatosOrdenador.Size = new System.Drawing.Size(233, 237);
            this.groupDatosOrdenador.TabIndex = 1;
            this.groupDatosOrdenador.TabStop = false;
            this.groupDatosOrdenador.Text = "Datos";
            this.groupDatosOrdenador.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(205, 179);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(13, 13);
            this.label17.TabIndex = 22;
            this.label17.Text = "€";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 178);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Precio";
            // 
            // btnImagenPC
            // 
            this.btnImagenPC.Location = new System.Drawing.Point(105, 201);
            this.btnImagenPC.Name = "btnImagenPC";
            this.btnImagenPC.Size = new System.Drawing.Size(100, 23);
            this.btnImagenPC.TabIndex = 15;
            this.btnImagenPC.Text = "Añadir imagen";
            this.btnImagenPC.UseVisualStyleBackColor = true;
            this.btnImagenPC.Click += new System.EventHandler(this.btnImagenPC_Click);
            // 
            // txtPrecioPC
            // 
            this.txtPrecioPC.Location = new System.Drawing.Point(105, 175);
            this.txtPrecioPC.Name = "txtPrecioPC";
            this.txtPrecioPC.Size = new System.Drawing.Size(100, 20);
            this.txtPrecioPC.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Procesador";
            // 
            // txtProcesadorPC
            // 
            this.txtProcesadorPC.Location = new System.Drawing.Point(105, 149);
            this.txtProcesadorPC.Name = "txtProcesadorPC";
            this.txtProcesadorPC.Size = new System.Drawing.Size(100, 20);
            this.txtProcesadorPC.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Almacenamiento";
            // 
            // txtAlmacenamientoPC
            // 
            this.txtAlmacenamientoPC.Location = new System.Drawing.Point(105, 123);
            this.txtAlmacenamientoPC.Name = "txtAlmacenamientoPC";
            this.txtAlmacenamientoPC.Size = new System.Drawing.Size(100, 20);
            this.txtAlmacenamientoPC.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "RAM";
            // 
            // txtRAMPC
            // 
            this.txtRAMPC.Location = new System.Drawing.Point(105, 97);
            this.txtRAMPC.Name = "txtRAMPC";
            this.txtRAMPC.Size = new System.Drawing.Size(100, 20);
            this.txtRAMPC.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "GPU";
            // 
            // txtGPUPC
            // 
            this.txtGPUPC.Location = new System.Drawing.Point(105, 71);
            this.txtGPUPC.Name = "txtGPUPC";
            this.txtGPUPC.Size = new System.Drawing.Size(100, 20);
            this.txtGPUPC.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Marca";
            // 
            // txtMarcaPC
            // 
            this.txtMarcaPC.Location = new System.Drawing.Point(105, 45);
            this.txtMarcaPC.Name = "txtMarcaPC";
            this.txtMarcaPC.Size = new System.Drawing.Size(100, 20);
            this.txtMarcaPC.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Código";
            // 
            // txtCodigoPC
            // 
            this.txtCodigoPC.Location = new System.Drawing.Point(105, 19);
            this.txtCodigoPC.Name = "txtCodigoPC";
            this.txtCodigoPC.Size = new System.Drawing.Size(100, 20);
            this.txtCodigoPC.TabIndex = 0;
            // 
            // groupDatosMovil
            // 
            this.groupDatosMovil.Controls.Add(this.label20);
            this.groupDatosMovil.Controls.Add(this.label18);
            this.groupDatosMovil.Controls.Add(this.label15);
            this.groupDatosMovil.Controls.Add(this.txtPrecioMovil);
            this.groupDatosMovil.Controls.Add(this.label2);
            this.groupDatosMovil.Controls.Add(this.txtProcesadorMovil);
            this.groupDatosMovil.Controls.Add(this.label9);
            this.groupDatosMovil.Controls.Add(this.btnImagenMovil);
            this.groupDatosMovil.Controls.Add(this.txtCamaraMovil);
            this.groupDatosMovil.Controls.Add(this.label10);
            this.groupDatosMovil.Controls.Add(this.txtAlmacenamientoMovil);
            this.groupDatosMovil.Controls.Add(this.label11);
            this.groupDatosMovil.Controls.Add(this.txtRAMMovil);
            this.groupDatosMovil.Controls.Add(this.label12);
            this.groupDatosMovil.Controls.Add(this.txtModeloMovil);
            this.groupDatosMovil.Controls.Add(this.label13);
            this.groupDatosMovil.Controls.Add(this.txtMarcaMovil);
            this.groupDatosMovil.Controls.Add(this.label14);
            this.groupDatosMovil.Controls.Add(this.txtCodigoMovil);
            this.groupDatosMovil.Location = new System.Drawing.Point(218, 12);
            this.groupDatosMovil.Name = "groupDatosMovil";
            this.groupDatosMovil.Size = new System.Drawing.Size(232, 262);
            this.groupDatosMovil.TabIndex = 14;
            this.groupDatosMovil.TabStop = false;
            this.groupDatosMovil.Text = "Datos";
            this.groupDatosMovil.Visible = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(205, 205);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(13, 13);
            this.label18.TabIndex = 23;
            this.label18.Text = "€";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 204);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 13);
            this.label15.TabIndex = 15;
            this.label15.Text = "Precio";
            // 
            // txtPrecioMovil
            // 
            this.txtPrecioMovil.Location = new System.Drawing.Point(105, 201);
            this.txtPrecioMovil.Name = "txtPrecioMovil";
            this.txtPrecioMovil.Size = new System.Drawing.Size(100, 20);
            this.txtPrecioMovil.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 178);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Procesador";
            // 
            // txtProcesadorMovil
            // 
            this.txtProcesadorMovil.Location = new System.Drawing.Point(105, 175);
            this.txtProcesadorMovil.Name = "txtProcesadorMovil";
            this.txtProcesadorMovil.Size = new System.Drawing.Size(100, 20);
            this.txtProcesadorMovil.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 152);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Cámara";
            // 
            // btnImagenMovil
            // 
            this.btnImagenMovil.Location = new System.Drawing.Point(105, 227);
            this.btnImagenMovil.Name = "btnImagenMovil";
            this.btnImagenMovil.Size = new System.Drawing.Size(100, 23);
            this.btnImagenMovil.TabIndex = 16;
            this.btnImagenMovil.Text = "Añadir imagen";
            this.btnImagenMovil.UseVisualStyleBackColor = true;
            this.btnImagenMovil.Click += new System.EventHandler(this.btnImagenMovil_Click);
            // 
            // txtCamaraMovil
            // 
            this.txtCamaraMovil.Location = new System.Drawing.Point(105, 149);
            this.txtCamaraMovil.Name = "txtCamaraMovil";
            this.txtCamaraMovil.Size = new System.Drawing.Size(100, 20);
            this.txtCamaraMovil.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 126);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Almacenamiento";
            // 
            // txtAlmacenamientoMovil
            // 
            this.txtAlmacenamientoMovil.Location = new System.Drawing.Point(105, 123);
            this.txtAlmacenamientoMovil.Name = "txtAlmacenamientoMovil";
            this.txtAlmacenamientoMovil.Size = new System.Drawing.Size(100, 20);
            this.txtAlmacenamientoMovil.TabIndex = 8;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 100);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "RAM";
            // 
            // txtRAMMovil
            // 
            this.txtRAMMovil.Location = new System.Drawing.Point(105, 97);
            this.txtRAMMovil.Name = "txtRAMMovil";
            this.txtRAMMovil.Size = new System.Drawing.Size(100, 20);
            this.txtRAMMovil.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 74);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Modelo";
            // 
            // txtModeloMovil
            // 
            this.txtModeloMovil.Location = new System.Drawing.Point(105, 71);
            this.txtModeloMovil.Name = "txtModeloMovil";
            this.txtModeloMovil.Size = new System.Drawing.Size(100, 20);
            this.txtModeloMovil.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 48);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "Marca";
            // 
            // txtMarcaMovil
            // 
            this.txtMarcaMovil.Location = new System.Drawing.Point(105, 45);
            this.txtMarcaMovil.Name = "txtMarcaMovil";
            this.txtMarcaMovil.Size = new System.Drawing.Size(100, 20);
            this.txtMarcaMovil.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Código";
            // 
            // txtCodigoMovil
            // 
            this.txtCodigoMovil.Location = new System.Drawing.Point(105, 19);
            this.txtCodigoMovil.Name = "txtCodigoMovil";
            this.txtCodigoMovil.Size = new System.Drawing.Size(100, 20);
            this.txtCodigoMovil.TabIndex = 0;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(227, 320);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 17;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(348, 320);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 18;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 197);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(149, 146);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 181);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(111, 13);
            this.label16.TabIndex = 20;
            this.label16.Text = "Imagen seleccionada:";
            // 
            // lblNingunaImagenCargada
            // 
            this.lblNingunaImagenCargada.AutoSize = true;
            this.lblNingunaImagenCargada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNingunaImagenCargada.ForeColor = System.Drawing.Color.Red;
            this.lblNingunaImagenCargada.Location = new System.Drawing.Point(22, 261);
            this.lblNingunaImagenCargada.Name = "lblNingunaImagenCargada";
            this.lblNingunaImagenCargada.Size = new System.Drawing.Size(128, 12);
            this.lblNingunaImagenCargada.TabIndex = 21;
            this.lblNingunaImagenCargada.Text = "Ninguna imagen cargada";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(205, 101);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(22, 13);
            this.label19.TabIndex = 23;
            this.label19.Text = "GB";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(205, 101);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(22, 13);
            this.label20.TabIndex = 24;
            this.label20.Text = "GB";
            // 
            // AddProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 351);
            this.Controls.Add(this.lblNingunaImagenCargada);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.groupDatosMovil);
            this.Controls.Add(this.groupDatosOrdenador);
            this.Controls.Add(this.groupBox1);
            this.Name = "AddProductForm";
            this.Text = "AddProductForm";
            this.Load += new System.EventHandler(this.AddProductForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupDatosOrdenador.ResumeLayout(false);
            this.groupDatosOrdenador.PerformLayout();
            this.groupDatosMovil.ResumeLayout(false);
            this.groupDatosMovil.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnMovil;
        private System.Windows.Forms.RadioButton rbtnOrdenador;
        private System.Windows.Forms.GroupBox groupDatosOrdenador;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPrecioPC;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtProcesadorPC;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAlmacenamientoPC;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtRAMPC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtGPUPC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMarcaPC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCodigoPC;
        private System.Windows.Forms.GroupBox groupDatosMovil;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtPrecioMovil;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtProcesadorMovil;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCamaraMovil;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtAlmacenamientoMovil;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtRAMMovil;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtModeloMovil;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtMarcaMovil;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCodigoMovil;
        private System.Windows.Forms.Button btnImagenPC;
        private System.Windows.Forms.Button btnImagenMovil;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblNingunaImagenCargada;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
    }
}