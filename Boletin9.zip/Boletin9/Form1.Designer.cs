﻿namespace Boletin9
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEj1 = new System.Windows.Forms.Button();
            this.btnEj2 = new System.Windows.Forms.Button();
            this.btnEj3 = new System.Windows.Forms.Button();
            this.btnEj4 = new System.Windows.Forms.Button();
            this.btnEj5 = new System.Windows.Forms.Button();
            this.btnEj6 = new System.Windows.Forms.Button();
            this.btnEj7 = new System.Windows.Forms.Button();
            this.btnEj8 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEj1
            // 
            this.btnEj1.Location = new System.Drawing.Point(12, 12);
            this.btnEj1.Name = "btnEj1";
            this.btnEj1.Size = new System.Drawing.Size(103, 49);
            this.btnEj1.TabIndex = 0;
            this.btnEj1.Text = "Ejercicio 1";
            this.btnEj1.UseVisualStyleBackColor = true;
            this.btnEj1.Click += new System.EventHandler(this.btnEj1_Click);
            // 
            // btnEj2
            // 
            this.btnEj2.Location = new System.Drawing.Point(121, 12);
            this.btnEj2.Name = "btnEj2";
            this.btnEj2.Size = new System.Drawing.Size(103, 49);
            this.btnEj2.TabIndex = 1;
            this.btnEj2.Text = "Ejercicio 2";
            this.btnEj2.UseVisualStyleBackColor = true;
            this.btnEj2.Click += new System.EventHandler(this.btnEj2_Click);
            // 
            // btnEj3
            // 
            this.btnEj3.Location = new System.Drawing.Point(230, 12);
            this.btnEj3.Name = "btnEj3";
            this.btnEj3.Size = new System.Drawing.Size(103, 49);
            this.btnEj3.TabIndex = 2;
            this.btnEj3.Text = "Ejercicio 3";
            this.btnEj3.UseVisualStyleBackColor = true;
            this.btnEj3.Click += new System.EventHandler(this.btnEj3_Click);
            // 
            // btnEj4
            // 
            this.btnEj4.Location = new System.Drawing.Point(339, 12);
            this.btnEj4.Name = "btnEj4";
            this.btnEj4.Size = new System.Drawing.Size(103, 49);
            this.btnEj4.TabIndex = 3;
            this.btnEj4.Text = "Ejercicio 4";
            this.btnEj4.UseVisualStyleBackColor = true;
            this.btnEj4.Click += new System.EventHandler(this.btnEj4_Click);
            // 
            // btnEj5
            // 
            this.btnEj5.Location = new System.Drawing.Point(12, 67);
            this.btnEj5.Name = "btnEj5";
            this.btnEj5.Size = new System.Drawing.Size(103, 49);
            this.btnEj5.TabIndex = 4;
            this.btnEj5.Text = "Ejercicio 5";
            this.btnEj5.UseVisualStyleBackColor = true;
            this.btnEj5.Click += new System.EventHandler(this.btnEj5_Click);
            // 
            // btnEj6
            // 
            this.btnEj6.Location = new System.Drawing.Point(121, 67);
            this.btnEj6.Name = "btnEj6";
            this.btnEj6.Size = new System.Drawing.Size(103, 49);
            this.btnEj6.TabIndex = 5;
            this.btnEj6.Text = "Ejercicio 6";
            this.btnEj6.UseVisualStyleBackColor = true;
            this.btnEj6.Click += new System.EventHandler(this.btnEj6_Click);
            // 
            // btnEj7
            // 
            this.btnEj7.Location = new System.Drawing.Point(230, 67);
            this.btnEj7.Name = "btnEj7";
            this.btnEj7.Size = new System.Drawing.Size(103, 49);
            this.btnEj7.TabIndex = 6;
            this.btnEj7.Text = "Ejercicio 7";
            this.btnEj7.UseVisualStyleBackColor = true;
            this.btnEj7.Click += new System.EventHandler(this.btnEj7_Click);
            // 
            // btnEj8
            // 
            this.btnEj8.Location = new System.Drawing.Point(339, 67);
            this.btnEj8.Name = "btnEj8";
            this.btnEj8.Size = new System.Drawing.Size(103, 49);
            this.btnEj8.TabIndex = 7;
            this.btnEj8.Text = "Ejercicio 8";
            this.btnEj8.UseVisualStyleBackColor = true;
            this.btnEj8.Click += new System.EventHandler(this.btnEj8_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(670, 321);
            this.Controls.Add(this.btnEj8);
            this.Controls.Add(this.btnEj7);
            this.Controls.Add(this.btnEj6);
            this.Controls.Add(this.btnEj5);
            this.Controls.Add(this.btnEj4);
            this.Controls.Add(this.btnEj3);
            this.Controls.Add(this.btnEj2);
            this.Controls.Add(this.btnEj1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEj1;
        private System.Windows.Forms.Button btnEj2;
        private System.Windows.Forms.Button btnEj3;
        private System.Windows.Forms.Button btnEj4;
        private System.Windows.Forms.Button btnEj5;
        private System.Windows.Forms.Button btnEj6;
        private System.Windows.Forms.Button btnEj7;
        private System.Windows.Forms.Button btnEj8;
    }
}

